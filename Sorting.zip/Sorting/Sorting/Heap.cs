﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;
using System.IO;
using System.Data;


namespace Sorting
{
    class Heap
    {

		public static void Main()
		{
			string Datafile = "scores.txt";
			var linear = File.ReadAllLines(Datafile);
			WriteLine("This is how you do a Heap sort");
			WriteLine("The algorithm divides its input into a sorted and an unsorted region, " +
				"and it iteratively shrinks the unsorted region by grabbing the largest number from it " +
				"and inserting it into the sorted region. ");
			File.WriteAllLines("scores.txt", linear);
			foreach (string phrase in linear)
				Write(phrase + "\n ");
			string[] linear1 = { "scores.txt" };
			string temp;
			int numLength = linear1.Length;

            int n = 10, i;
            WriteLine("Heap Sort");
            Write("Initial array is: ");
            for (i = 0; i < n; i++)
            {
                Write(linear1[i] + " ");
            }
            heapSort(linear1, 10);
            Console.Write("\nSorted Array is: ");
            for (i = 0; i < n; i++)
            {
                Write(linear1[i] + " ");
            }
        }

        static void heapSort(int[] body, int n)
        {
            for (int i = n / 2 - 1; i >= 0; i--)
                heaping(body, n, i);
            for (int i = n - 1; i >= 0; i--)
            {
                int temp = body[0];
                body[0] = body[i];
                body[i] = temp;
                heaping(body, i, 0);
            }
        }
        static void heaping(int[] arr, int n, int i)
        {
            int largest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;
            if (left < n && arr[left] > arr[largest])
                largest = left;
            if (right < n && arr[right] > arr[largest])
                largest = right;
            if (largest != i)
            {
                int swap = arr[i];
                arr[i] = arr[largest];
                arr[largest] = swap;
                heaping(arr, n, largest);
            }
        }

        //pseudocode
        //Heapsort(Data: values)
        //<Turn the array into a heap.>
        //For i = < length of values> - 1 To 0 Step -1
        // Swap the root item and the last item.
        //Data: temp = values[0]
        //values[0] = values[i]
        //values[i] = temp
        //< Consider the item in position i to be removed from the heap,so the heap now holds i - 1 items.Push the new root value
        //down into the heap to restore the heap property.>
        //Next i
        //End Heapsort


    }
}
