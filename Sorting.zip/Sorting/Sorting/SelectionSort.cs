﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;
using System.IO;
using System.Data;

namespace Sorting
{
    class SelectionSort
    {
        public static void selection_sort()
        {
            
            string Datafile = "scores.txt";
            var linear = File.ReadAllLines(Datafile);
            File.WriteAllLines("scores.txt", linear);
            foreach (string phrase in linear)
                Write(phrase + "\n ");
            string[] linear1 = { "scores.txt" };
            int n = 10;
            string temp;
            int numLength = linear1.Length;
            WriteLine("Selection sort");
            WriteLine("This algorithm finds the minimum value in the array for each iteration of the loop. " +
                "Then this minimum value is swapped with the current array element until it sort everything out.");
            Write("Initial array is: ");
            for (int i = 0; i < n; i++)
            {
                Write(linear[i] + " ");
            }
            string smallest;
            for (int i = 0; i < n - 1; i++)
            {
                smallest = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (linear[j] < linear1[smallest])
                    {
                        smallest = j;
                    }
                }
                temp = linear1[smallest];
                [smallest] = linear1[i];
                linear1[i] = temp;
            }
            WriteLine();
            Write("Sorted array is: ");
            for (int i = 0; i < n; i++)
            {
                Write(linear[i] + " ");
            }

        }
        //pseudocode 
        //for (i = 0 ; i < n-1 ; i++){
        //index = i;
         //for(j = i+1 ; j<n ; j++)
         //{
        // if(txt[j] < A[index])
        //index = j;
        // }
        //temp = txt[i];
        //txt[i] = txt[index];
        //txt[index] = temp;
        //}
    }
}
