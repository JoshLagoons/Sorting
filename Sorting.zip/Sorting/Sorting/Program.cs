﻿using System;
using static System.Console;
using System.Collections;
using System.Data;
using System.IO;
using System.Timers;
namespace Sorting
{
    class Program
    {
        private static System.Timers.Timer aTimer;
        static void Main(string[] args)
        {
            WriteLine("Selection which Sort to use: 1) Bubble Sort\n2) Insertion Sort\n3) Selection Sort\n4) Merge Sort\n5) Quick Sort\n6) Heap Sort");
            Write("Please enter your selection: ");
            string sorts = ReadLine();
            switch (sorts)
            {
                case "1":
                case "Bubble sort":
                    BubbleSort bubble = new BubbleSort();
                    break;
                case "2":
                case "Insertion sort":
                    InsertionSort insert = new InsertionSort(); 
                    break;
                case "3":
                case "Selection sort":
                    SelectionSort select = new SelectionSort();
                    break;
                case "4":
                case "Merge sort":
                    MergeSort merge = new MergeSort();
                    break;
                case "5":
                case "Quick sort":
                    QuickSort quick = new QuickSort();
                    break;
                case "6":
                case "Heap sort":
                    Heap hep = new Heap();
                    break;
                default:
                    WriteLine("Invalid selection. Please select 1, 2, or 3.");
                    break;
                    SetTimer();

                    Console.WriteLine("\nPress the Enter key to exit the application...\n");
                    Console.WriteLine("The application started at {0:HH:mm:ss.fff}", DateTime.Now);
                    Console.ReadLine();
                    aTimer.Stop();
                    aTimer.Dispose();

                    Console.WriteLine("Terminating the application...");

            }


        }
        private static void SetTimer()
        {
            // Create a timer with a two second interval.
            aTimer = new System.Timers.Timer(2000);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            Console.WriteLine("The Elapsed event was raised at {0:HH:mm:ss.fff}",
                              e.SignalTime);
        }
    }
}

