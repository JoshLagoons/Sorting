﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;
using System.IO;
using System.Data;

namespace Sorting
{
    class QuickSort
    {
        static void pop(string[] args)
        {
            string Datafile = "scores.txt";
            var linear = File.ReadAllLines(Datafile);
            File.WriteAllLines("scores.txt", linear);
            foreach (string phrase in linear)
                Write(phrase + "\n ");
            string[] linear1 = { "scores.txt" };
            string temp;
            int numLength = linear1.Length;
            WriteLine("This is the quick sort");
            WriteLine("Is a comparison sorting on how it can sort items of any type that is a less than relation");
            string[] body = new string[] {"scores.txt"};

            WriteLine("Original array : ");
            foreach (var item in body)
            {
                Write(" " + item);
            }
            WriteLine();

            Quick_Sort(body, 0, body.Length - 1);

            WriteLine();
            WriteLine("Sorted array : ");

            foreach (var item in body)
            {
                Write(" " + item);
            }
            WriteLine();
        }
        //the algorithm for it to obtain
        private static void Quick_Sort(string[] body, int left, int right)
        {
            if (left < right)
            {
                int wide = Partition(body, left, right);

                if (wide > 1)
                {
                    Quick_Sort(body, left, wide - 1);
                }
                if (wide + 1 < right)
                {
                    Quick_Sort(body, wide + 1, right);
                }
            }

        }
        //commands for it to function properly on the left and right
        private static int Partition(int[] body, int left, int right)
        {
            int wide = body[left];
            while (true)
            {

                while (body[left] < wide)
                {
                    left++;
                }

                while (body[right] > wide)
                {
                    right--;
                }

                if (left < right)
                {
                    if (body[left] == body[right]) return right;

                    int temp = body[left];
                    body[left] = body[right];
                   body[right] = temp;


                }
                else
                {
                    return right;
                }
            }
        }
        //pseudocode
        //algorithm quicksort(A, lo, hi) is
        //if lo<hi then
        //p := pivot(A, lo, hi)
        //left, right := partition(A, p, lo, hi)  // note: multiple return values
        //quicksort(A, lo, left - 1)
        //quicksort(A, right + 1, hi)


    }
}

