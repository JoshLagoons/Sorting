﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;
using System.IO;
using System.Data;

namespace Sorting
{
    class BubbleSort
    {
        private static void bubble_sort()
        {
            WriteLine("Here's the bubble sort");
            WriteLine("The sorting basically is bubbling up as to their proper location in an array similar to bubbles rising on a drink");
            string Datafile = "scores.txt";
            var linear = File.ReadAllLines(Datafile);
            WriteLine("This is how you do a bubble sort");
            File.WriteAllLines("scores.txt", linear);
            foreach (string phrase in linear)
                //loops it every time you boot it up again
                Write(phrase + "\n ");
            string[] linear1 = {"scores.txt"};
            string temp;
            int numLength = linear1.Length;

            //this is sorting the numbers in the txt file
            for (int j = 0; j <= linear1.Length - 2; j++)
            {
                for (int i = 0; i <= linear1.Length - 2; i++)
                {
                    if (string[linear1[i]] > string[linear1[i + 1]])
                    {
                        temp = linear1[i + 1];
                        linear1[i + 1] = linear1[i];
                        linear1[i] = temp;
                    }
                }
            }

            //will print out the file with all the numbers organized.
            WriteLine("Sorted:");
            foreach (string p in linear1)
            Write(p + " ");
            Read();
         

        }
        //pseudocode
        //
        //Set Flag := True
        //Repeat Steps from 3 to 5 for I = 1 to N-1 while Flag == true
        //Set Flag := False
        //Set J:=0. [Initialize pass pointer J]
        //Repeat while J<N-1 [Executes pass]
        //(a) If DATA[J + 1]>DATA[J], then:
        //Swap DATA[J] and DATA[J + 1]
        //Set Flag:= True
        //[End of If structure]
        //(b) Set J:=J+1
        //[End of inner loop]
        //[End of step 1 outer loop]
        //Exit

    }
}
