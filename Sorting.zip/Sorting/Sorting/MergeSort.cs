﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;
using System.IO;
using System.Data;

namespace Sorting
{
    class MergeSort
    {
        public static int[] mergeSort(int[] array)
        {

            string Datafile = "scores.txt";
            var linear = File.ReadAllLines(Datafile);
            File.WriteAllLines("scores.txt", linear);
            foreach (string phrase in linear)
                Write(phrase + "\n ");
            string[] linear1 = { "scores.txt" };
            string temp;
            int numLength = linear1.Length;
            WriteLine("This is merge sort");
            WriteLine("it's an algorithm that splits an array into two halves (sub arrays) " +
                "and recursively sorts each sub array before merging them back into one giant, sorted array.");
            int[] left;
            int[] right;
            int[] result = new int[array.Length];
            //As this is a recursive algorithm, we need to have a base case to 
            //avoid an infinite recursion and therfore a stackoverflow
            if (array.Length <= 1)
                return array;
            // The exact midpoint of our array  
            int midPoint = array.Length / 2;
            //Will represent our 'left' array
            left = new int[midPoint];

            //if array has an even number of elements, the left and right array will have the same number of 
            //elements
            if (array.Length % 2 == 0)
                right = new int[midPoint];
            //if array has an odd number of elements, the right array will have one more element than left
            else
                right = new int[midPoint + 1];
            //produces the left 
            for (int i = 0; i < midPoint; i++)
                left[i] = array[i];
            //produces the right 
            int x = 0;
           
            for (int i = midPoint; i < array.Length; i++)
            {
                right[x] = array[i];
                x++;
            }
            //Sorting the left 
            left = mergeSort(left);
            //RSorting the right
            right = mergeSort(right);
            //Merge our two sorted arrays
            result = merge(left, right);
            return result;
        }

        //This method will be responsible for combining our two sorted arrays into one big array
        public static int[] merge(int[] left, int[] right)
        {
            int resultLength = right.Length + left.Length;
            int[] result = new int[resultLength];
            int indexLeft = 0, indexRight = 0, indexResult = 0;
            //while either array still has an element
            while (indexLeft < left.Length || indexRight < right.Length)
            {
                //the probability of both arrays have elements  
                if (indexLeft < left.Length && indexRight < right.Length)
                {
                    //If item on left array is less than item on right array, add that item to the result array 
                    if (left[indexLeft] <= right[indexRight])
                    {
                        result[indexResult] = left[indexLeft];
                        indexLeft++;
                        indexResult++;
                    }
                    // else the item in the right array wll be added to the results array
                    else
                    {
                        result[indexResult] = right[indexRight];
                        indexRight++;
                        indexResult++;
                    }
                }
                //if only the left array still has elements, add all its items to the results array
                else if (indexLeft < left.Length)
                {
                    result[indexResult] = left[indexLeft];
                    indexLeft++;
                    indexResult++;
                }
                //if only the right array still has elements, add all its items to the results array
                else if (indexRight < right.Length)
                {
                    result[indexResult] = right[indexRight];
                    indexRight++;
                    indexResult++;
                }
            }
            return result;
        }
        //pseudocode
        //Mergesort(Data: values[], Data: scratch[], Integer: start, Integer: end)
        // If the array contains only one item, it is already sorted.
        //If(start == end) Then Return
        // Break the array into left and right halves.
        //Integer: midpoint = (start + end) / 2
        // Call Mergesort to sort the two halves.
        //Mergesort(values, scratch, start, midpoint)
        //Mergesort(values, scratch, midpoint + 1, end)
        // Merge the two sorted halves.
        //Integer: left_index = start
        //Integer: right_index = midpoint + 1
        //Integer: scratch_index = left_index
        //While((left_index <= midpoint) And(right_index <= end))
        //If(values[left_index] <= values[right_index]) Then
        //scratch[scratch_index] = values[left_index]
        //left_index = left_index + 1
        //Else
        //scratch[scratch_index] = values[right_index]
        //right_index = right_index + 1
        //End If
        //scratch_index = scratch_index + 1    End While

    // Finish copying whichever half is not empty.
        //For i = left_index To midpoint
        //scratch[scratch_index] = values[i]
        //scratch_index = scratch_index + 1
    //Next i
    //For i = right_index To end

    //scratch[scratch_index] = values[i]
    //scratch_index = scratch_index + 1
    //Next i
    // Copy the values back into the original values array.
    //For i = start To end
    //values[i] = scratch[i]
    //Next i
    }
}
