﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;
using System.IO;
using System.Data;

namespace Sorting
{
    class InsertionSort
    {
        public static int InsertionSorting()
        {
            WriteLine("Here's the insertion sort\n");
            WriteLine("The algorithm takes an element from the source and places it in the correct location from the txt file. " +
                "This process is repeated until there are no more unsorted items from the file. ");
            string Datafile = "scores.txt";
            var linear = File.ReadAllLines(Datafile);
            File.WriteAllLines("scores.txt", linear);
            foreach (string phrase in linear)
                Write(phrase + "\n ");
            Write("\n\nEnter number of elements: ");
            int max = Convert.ToInt32(linear);
            int[] numarray = new int[max];
            for (int i = 0; i < max; i++)
            {
                Write("\nEnter [" + (i + 1).ToString() + "] element: ");
                numarray[i] = Convert.ToInt32(ReadLine());
            }
            Write("Input int array  : ");
            for (int k = 0; k < max; k++)
            Write(numarray[k] + " ");
            Write("\n");
            for (int i = 1; i < max; i++)
            {
                int j = i;
                while (j > 0)
                {
                    if (numarray[j - 1] > numarray[j])
                    {
                        int temp = numarray[j - 1];
                        numarray[j - 1] = numarray[j];
                        numarray[j] = temp;
                        j--;
                    }
                    else
                        break;
                }
                Write("Iteration " + i.ToString() + ": ");
                for (int k = 0; k < max; k++)
                    Write(numarray[k] + " ");
                Write("\n");
            }
            Write("\n\nThe numbers in ascending orders are given below:\n\n");
            for (int i = 0; i < max; i++)
            {
                Write("Sorted [" + (i + 1).ToString() + "] element: ");
                Write(numarray[i]);
                Write("\n");
            }
            return 0;
        }
        //pseudocode

        //For j ← 2 TO length[txt file]
        //Do key ← txt[j] 
        //{Put txt[j] into the sorted sequence txt[1. .j − 1]}
        //i ← j − 1 
        //While i > 0 and txt[i] > key
        //Do txt[i + 1] ← txt[i]
        //i ← i − 1 
        //txt[i + 1] ← key

}
}
